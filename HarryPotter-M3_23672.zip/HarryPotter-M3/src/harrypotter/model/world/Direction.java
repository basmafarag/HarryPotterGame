package harrypotter.model.world;

public enum Direction {
	FORWARD, BACKWARD, RIGHT, LEFT;
}
