package harrypotter.model.world;

public class WallCell extends Cell {

}
